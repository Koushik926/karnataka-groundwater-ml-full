# Team Work Division

## Project: Spatio-Temporal Prediction and Risk Mapping of Groundwater Depletion in Karnataka

---

## MODULE 1: Groundwater Level Prediction
### Team: KOUSHIK (R23EJ096) + KARTHIK (R23EJ168)

### What You Built:
- Data collection from CGWB National Water Data Portal
- Data preprocessing pipeline
- ML model training (Random Forest, XGBoost, SVR)
- Model evaluation and selection
- Prediction output generation

### Files You Worked On:
```
src/data_processor.py    - Data loading and feature engineering
src/pipeline.py          - ML model training and evaluation
src/config.py            - Model hyperparameters
data/raw/*.csv           - Downloaded datasets
outputs/module1_*.csv    - Prediction outputs
```

### Key Concepts to Explain:

#### 1. Data Collection (Koushik)
**Q: Where did you get the data?**
> "We downloaded real groundwater level data from CGWB's National Water Data Portal (NWDP). The dataset contains 123,391 quarterly measurements from 2,769 monitoring stations across 33 districts of Karnataka, spanning 1996 to 2024."

**Q: What are the features in the dataset?**
> "The raw data has: Station ID, District, Block, Village, Latitude, Longitude, Date, and Groundwater Level in meters. We engineered additional features like lag values (previous 1-4 quarters), rolling mean/std, and seasonal encoding."

#### 2. Data Preprocessing (Koushik)
**Q: How did you handle missing values?**
> "We removed 241 outliers where GWL was negative or greater than 100 meters (impossible values). We also filtered stations with at least 20 records to ensure enough history for lag features."

**Q: What features did you create?**
> "We created:
> - Lag features: GWL from 1, 2, 3, 4 quarters ago
> - Rolling statistics: Mean and Std over past year
> - Seasonal encoding: sin/cos of month (captures monsoon patterns)
> - Location features: Latitude and Longitude"

#### 3. ML Models (Karthik)
**Q: Why did you choose these algorithms?**
> "Random Forest: Handles non-linear relationships, robust to outliers, gives feature importance.
> XGBoost: State-of-the-art for tabular data, has regularization to prevent overfitting.
> SVR: Good baseline for comparison, works with RBF kernel for non-linear patterns."

**Q: How did you split the data?**
> "We used chronological splitting - 70% training, 15% validation, 15% test. This preserves temporal order because we're predicting future values."

#### 4. Model Evaluation (Karthik)
**Q: What metrics did you use?**
> "RMSE (Root Mean Squared Error): Measures prediction error in meters
> MAE (Mean Absolute Error): Average absolute error
> R² (Coefficient of Determination): How much variance the model explains"

**Q: Which model performed best?**
> "XGBoost performed best with:
> - Validation RMSE: 3.63 meters
> - Validation R²: 0.40
> We selected it automatically based on lowest RMSE."

### Code Snippets to Remember:

```python
# Feature Engineering (Koushik)
for lag in [1, 2, 3, 4]:
    df[f'GWL_lag{lag}'] = df.groupby('Station')['GWL_m'].shift(lag)

df['GWL_rolling_mean'] = df.groupby('Station')['GWL_m'].transform(
    lambda x: x.rolling(window=4).mean().shift(1)
)

# Model Training (Karthik)
models['XGBoost'] = xgb.XGBRegressor(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=6
)
models['XGBoost'].fit(X_train, y_train)

# Model Evaluation
rmse = np.sqrt(mean_squared_error(y_val, preds))
r2 = r2_score(y_val, preds)
```

---

## MODULE 2: Depletion Risk Mapping
### Team: VARSHITH (R23EJ100) + NITHIN (R23EJ088) + CHANDRASHEKAR (R23EQ029)

### What You Built:
- AHP (Analytic Hierarchy Process) weight calculation
- Risk indicator computation
- Jenks Natural Breaks classification
- Risk zone categorization
- Dashboard visualization
- EDA visualizations

### Files You Worked On:
```
src/module2_risk.py      - AHP weights, Jenks classification
src/config.py            - AHP matrix, risk indicators
dashboard.py             - Streamlit visualization
notebooks/eda_analysis.py - EDA plots
outputs/eda_plots/*.png  - Visualization outputs
outputs/module2_*.csv    - Risk mapping outputs
```

### Key Concepts to Explain:

#### 1. AHP Weight Calculation (Varshith)
**Q: What is AHP?**
> "AHP (Analytic Hierarchy Process) is a decision-making method by Saaty. We use it to assign weights to risk indicators based on their relative importance. We create a pairwise comparison matrix where each indicator is compared against others on a 1-9 scale."

**Q: What are your risk indicators?**
> "Five indicators:
> 1. Predicted Decline Rate (weight: 0.50) - from Module 1 predictions
> 2. Current Depth (weight: 0.26) - how deep the water table is
> 3. Variability (weight: 0.13) - coefficient of variation
> 4. Rainfall Dependence (weight: 0.07) - recovery correlation
> 5. LULC Change (weight: 0.03) - urbanization pressure"

**Q: How do you check if AHP is valid?**
> "We calculate the Consistency Ratio (CR). If CR < 0.10, the matrix is consistent. Our CR is 0.054, which is acceptable."

#### 2. Risk Classification (Nithin)
**Q: How do you calculate the risk index?**
> "We normalize each indicator to 0-1 range, then compute a weighted sum:
> Risk Index = Σ (weight_i × normalized_indicator_i)
> This gives a score between 0 (low risk) and 1 (high risk)."

**Q: What is Jenks Natural Breaks?**
> "Jenks is a classification method that minimizes variance within classes and maximizes variance between classes. It finds 'natural' groupings in the data. We use it to create 4 risk classes: Low, Moderate, High, Very High."

**Q: How do you validate the risk zones?**
> "We compare our classification against CGWB's official categories (Safe, Semi-critical, Critical, Over-exploited). Our accuracy is 68% with Cohen's Kappa of 0.54, indicating moderate agreement."

#### 3. Dashboard & Visualization (Chandrashekar)
**Q: What tools did you use for visualization?**
> "Streamlit for the dashboard (interactive web app), Plotly for charts (interactive), Matplotlib/Seaborn for static EDA plots."

**Q: What visualizations are in the dashboard?**
> "Three pages:
> 1. Overview: Key metrics, risk summary
> 2. Module 1: Model comparison charts, prediction time series
> 3. Module 2: Risk distribution pie/bar charts, indicator weights"

**Q: What insights did you find in EDA?**
> "Key findings:
> - Mean GWL is 7.31m, but varies significantly by district
> - Clear seasonal pattern - shallower during monsoon
> - Long-term trend shows gradual deepening over decades
> - 52 taluks are over-exploited, 10 are critical (27% at risk)"

### Code Snippets to Remember:

```python
# AHP Weight Calculation (Varshith)
AHP_MATRIX = [
    [1.0, 3.0, 5.0, 7.0, 9.0],   # predicted_decline_rate
    [1/3, 1.0, 3.0, 5.0, 7.0],   # current_depth
    [1/5, 1/3, 1.0, 3.0, 5.0],   # variability
    [1/7, 1/5, 1/3, 1.0, 3.0],   # rainfall_dependence
    [1/9, 1/7, 1/5, 1/3, 1.0],   # lulc_change
]

# Normalize and get weights
A_norm = A / A.sum(axis=0)
weights = A_norm.mean(axis=1)  # [0.50, 0.26, 0.13, 0.07, 0.03]

# Risk Index Calculation (Nithin)
risk_index = sum(weight[i] * normalized[i] for i in indicators)

# Jenks Classification
breaks = jenks_breaks(risk_index, n_classes=4)
# [0.15, 0.36, 0.54, 0.70, 0.88] - 4 break points

# Dashboard (Chandrashekar)
import streamlit as st
import plotly.express as px

st.title("Karnataka Groundwater Risk Dashboard")
fig = px.pie(risk_data, names="risk_label", title="Risk Distribution")
st.plotly_chart(fig)
```

---

## COMMON QUESTIONS FOR EVERYONE

**Q: What is the problem you're solving?**
> "Groundwater depletion is a critical issue in Karnataka. 52 taluks are over-exploited. Currently, monitoring is manual and reactive. We built an ML-based system to predict future groundwater levels and identify high-risk zones, so authorities can take proactive measures."

**Q: What data did you use?**
> "Real CGWB data from National Water Data Portal - 123,391 records, 33 districts, 28 years (1996-2024). Plus CGWB's 2020 assessment of 227 taluks with extraction and categorization data."

**Q: What are your key results?**
> "Module 1: XGBoost predicts GWL with RMSE of 3.63 meters
> Module 2: 27% of taluks are High/Very High risk, matching CGWB categories with 68% accuracy"

**Q: What's next?**
> "Integrate real-time data updates, implement spatial interpolation (Kriging), and deploy the dashboard for government planners."

---

## PRESENTATION SPEAKING ORDER

| Slide | Topic | Speaker |
|-------|-------|---------|
| 1-2 | Title, Team | Anyone |
| 3-4 | Problem Statement, Solution | Koushik |
| 5 | Literature Review | Karthik |
| 6-7 | Dataset Collection, Features | Koushik |
| 8 | Data Preprocessing | Koushik |
| 9-13 | EDA Visualizations | Chandrashekar |
| 14-15 | ML Algorithm Selection | Karthik |
| 16 | Model Implementation Code | Karthik |
| 17 | Model Evaluation | Karthik |
| 18 | Module 2: Risk Mapping | Varshith |
| 19-20 | Working Demo | Nithin |
| 21 | Dashboard | Chandrashekar |
| 22-23 | Conclusion, Thank You | Varshith |

---

## PRACTICE CHECKLIST

Before Saturday, each person should:

- [ ] Read this document thoroughly
- [ ] Run the demo script once: `python demo_saturday.py`
- [ ] Open and review the presentation slides
- [ ] Be able to explain YOUR module's code
- [ ] Know the answers to the questions above
- [ ] Practice your speaking part

**Remember**: You're a TEAM. If one person doesn't know, others can help. But each person MUST know their own module well.
